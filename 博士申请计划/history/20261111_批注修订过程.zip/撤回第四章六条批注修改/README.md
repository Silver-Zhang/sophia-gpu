# sophia-gpu

- [当前科研计划书 PDF](博士申请计划/exports/博士科研计划书_V2.1_第四章批注修订_20261111.pdf)
- [唯一 LaTeX 正文](博士申请计划/latex/main.tex)
- [修改过程与版本说明](博士申请计划/history/README.md)
- [文献与正文核查记录](博士申请计划/outline/当前版本_文献与正文核查_20261110.md)
- [项目说明](博士申请计划/README.md)
- [历史归档](archive/README.md)

当前25页，保留前三章修订正文，第四章完成4.1与4.2，4.3—4.5及第五章保留指定标题。参考文献51项。第四章6条批注已落实，附4张基准数据表。

检查：`cd 博士申请计划/latex && bash build.sh --check`。生成当前PDF：`bash build.sh`。

仅在develop本地工作，不自动提交、推送、合并或创建PR。批注原件、旧V5.3、图源与历史归档保留。LJC.docx为原有组会参考资料。
