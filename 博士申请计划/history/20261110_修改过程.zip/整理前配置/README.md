# sophia-gpu

- [博士科研计划书 V2.1第二章修订稿（PDF）](博士申请计划/exports/博士科研计划书_V2.1_第二章修订.pdf)
- [旧V5.3 PDF（保留）](博士申请计划/exports/博士科研计划书_V5.3.pdf)
- [LaTeX正文（V2.1第二章修订）](博士申请计划/latex/main.tex)
- [博士科研计划书重构提纲 V2.1](博士申请计划/outline/博士科研计划书_重构提纲_V2.1.md)
- [历史版本归档索引](archive/README.md)
- [开发目的、用户要求与最简修改记录](AGENTS.md)
- [文献图源与许可](博士申请计划/latex/references/figure_sources_v53.md)

验证：`cd 博士申请计划/latex && bash build.sh --check`；生成PDF用`bash build.sh`。

[LJC.docx](LJC.docx)为原有随机射线方法组会参考资料。旧版本和过程记录保留在Git历史。

[重构审查与待核查条件](博士申请计划/outline/重构审查_V2.1.md)。当前仅develop本地审阅，构建默认输出新版独立PDF。

[第二章批注与引用核查记录](博士申请计划/outline/第二章批注修订_20261110.md)。原重构初稿PDF含用户批注并保留，当前构建输出为独立第二章修订稿。
