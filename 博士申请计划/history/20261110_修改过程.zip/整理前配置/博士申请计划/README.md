# 博士申请计划

- 当前正文：[V2.1第二章批注修订LaTeX](latex/main.tex)
- 当前审阅PDF：[V2.1第二章批注修订](exports/博士科研计划书_V2.1_第二章修订.pdf)
- 唯一结构依据：[V2.1提纲](outline/博士科研计划书_重构提纲_V2.1.md)
- [重构计划、迁移说明、核查结果及剩余风险](outline/重构审查_V2.1.md)
- [当前图源](latex/references/figure_sources_v21.md)、[文献编号映射](latex/references/citation_map_v21.csv)、[元数据核查](latex/references/metadata_audit_v21.csv)
- [旧V5.3 PDF](exports/博士科研计划书_V5.3.pdf)与[历史归档](../archive/README.md)均保持不变。

仅在develop本地开发。`cd latex && bash build.sh --check`执行结构/引用检查和三遍XeLaTeX，不改导出；`bash build.sh`生成独立命名V2.1 PDF。不自动提交、推送、合并或创建PR。

[第一章批注落实与技术审查](outline/第一章批注修订_20261110.md)。批注原件保留，当前PDF已更新第一章。

[第二章批注、表1与迭代图修订及引文审查](outline/第二章批注修订_20261110.md) · [24项引文与主张核查CSV](latex/references/第二章_引文与主张核查.csv)。原重构初稿.pdf及副本含第二章批注，均保留不覆盖。
